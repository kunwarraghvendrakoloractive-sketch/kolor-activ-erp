Kolor Activ Production deployment

Vercel settings:
Build Command: npm run build
Output Directory: dist
Framework: Vite
Environment:
VITE_APP_MODE=production
VITE_SUPABASE_URL=https://cejqcynsxrxdfaszriwy.supabase.co
VITE_SUPABASE_ANON_KEY=<use Supabase publishable key>
